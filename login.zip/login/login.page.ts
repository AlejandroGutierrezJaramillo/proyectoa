import { Component} from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage{
  email: string='';
  password: string='';

  constructor() {}

  login() {
    // Aquí puedes agregar tu lógica para procesar el inicio de sesión
    console.log('Correo electrónico:', this.email);
    console.log('Contraseña:', this.password);
  }

  ngOnInit() {
  }
}
